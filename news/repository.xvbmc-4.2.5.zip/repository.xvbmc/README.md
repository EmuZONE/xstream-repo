# REPOsitory.XvBMC
 
**NOTE:** XvBMC Nederland (xbmc nl) wij zijn géén helpdesk van/voor boxverkopers
 
  
   
### XvBMC_Nederland: 
* https://bit.ly/XvBMC-NL 
* https://www.fb.com/groups/XvBMCnederland/ 
 
### OFFLINE / AFGESLOTEN / SHUTDOWN / DOWN: 
 
'XvBMC Nederland' heeft moeten besluiten met deze pagina te stoppen en op slot te zetten (per 26-07-2018),
ook de 'XvBMC Repository' is per ommegaande offline, cq. leeggehaald waardoor deze niet meer bruikbaar zal zijn.

De(ze) 'repo' zal alleen worden "vastgehouden" ter voorkoming van kaping in- en onder onze naam, een en ander om eventuele misstanden te voorkomen.
  
----------
  
*With kind regards,*
 
*Team X(v)BMC Nederland*
  
----------
  
(c) [XvBMC Nederland](https://bit.ly/XvBMC-NL) (r)