RauteMusik.FM Addon
===================

About
-----

The RauteMusik.FM AddOn integrates all radio stations of [RauteMusik
Internetradio] [1] into Kodi. RauteMusik.FM was founded in 2003 and has become
one of the largest internet radio networks in Europe. More than 300 members are
working hard in providing the best music of the last years and the current
charts.

Prerequisites
-------------

You need a working internet connection.

License
-------
This software is released under the [GPL 2.0 license] [2].

Useful Links
-------------

Official Repository Page: https://kodi.tv/addon/music-add-ons-plugins/rautemusik

Dedicated Repository: http://archive.yeasoft.net/repository.yeasoftbeta.zip

Support Forum: http://forum.kodi.tv/showthread.php?tid=2063156


[1]: http://rautemusik.fm
[2]: http://www.gnu.org/licenses/gpl-2.0.html
